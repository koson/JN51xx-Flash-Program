﻿
namespace DQS_Flash_JN5xx
{
    partial class Form_Flash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Flash));
            this.grPanel1 = new System.Windows.Forms.GroupBox();
            this.rtxStatus1 = new System.Windows.Forms.RichTextBox();
            this.cbBaudrate1 = new System.Windows.Forms.ComboBox();
            this.cbPortNamePanel1 = new System.Windows.Forms.ComboBox();
            this.lbCOM = new System.Windows.Forms.Label();
            this.lbBAUD = new System.Windows.Forms.Label();
            this.grBinData = new System.Windows.Forms.GroupBox();
            this.tbBinData = new System.Windows.Forms.TextBox();
            this.btBinData = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.cbLog = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cbVerify = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cbOTP = new System.Windows.Forms.CheckBox();
            this.grPanel2 = new System.Windows.Forms.GroupBox();
            this.rtxStatus2 = new System.Windows.Forms.RichTextBox();
            this.cbBaudrate2 = new System.Windows.Forms.ComboBox();
            this.cbPortNamePanel2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.grPanel3 = new System.Windows.Forms.GroupBox();
            this.rtxStatus3 = new System.Windows.Forms.RichTextBox();
            this.cbBaudrate3 = new System.Windows.Forms.ComboBox();
            this.cbPortNamePanel3 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.grPanel4 = new System.Windows.Forms.GroupBox();
            this.rtxStatus4 = new System.Windows.Forms.RichTextBox();
            this.cbBaudrate4 = new System.Windows.Forms.ComboBox();
            this.cbPortNamePanel4 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rtxStatus5 = new System.Windows.Forms.RichTextBox();
            this.cbBaudrate5 = new System.Windows.Forms.ComboBox();
            this.cbPortNamePanel5 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.grPanel6 = new System.Windows.Forms.GroupBox();
            this.rtxStatus6 = new System.Windows.Forms.RichTextBox();
            this.cbBaudrate6 = new System.Windows.Forms.ComboBox();
            this.cbPortNamePanel6 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btStartAll = new System.Windows.Forms.Button();
            this.btEraseAll = new System.Windows.Forms.Button();
            this.ttToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ofdOpen = new System.Windows.Forms.OpenFileDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.rtxStatusAll = new System.Windows.Forms.RichTextBox();
            this.tbStatusAll = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.grPanel1.SuspendLayout();
            this.grBinData.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.grPanel2.SuspendLayout();
            this.grPanel3.SuspendLayout();
            this.grPanel4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.grPanel6.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // grPanel1
            // 
            this.grPanel1.Controls.Add(this.pictureBox1);
            this.grPanel1.Controls.Add(this.rtxStatus1);
            this.grPanel1.Controls.Add(this.cbBaudrate1);
            this.grPanel1.Controls.Add(this.cbPortNamePanel1);
            this.grPanel1.Controls.Add(this.lbCOM);
            this.grPanel1.Controls.Add(this.lbBAUD);
            this.grPanel1.Location = new System.Drawing.Point(387, 15);
            this.grPanel1.Name = "grPanel1";
            this.grPanel1.Size = new System.Drawing.Size(373, 142);
            this.grPanel1.TabIndex = 0;
            this.grPanel1.TabStop = false;
            this.grPanel1.Text = "Panel Download 1";
            // 
            // rtxStatus1
            // 
            this.rtxStatus1.Location = new System.Drawing.Point(7, 19);
            this.rtxStatus1.Name = "rtxStatus1";
            this.rtxStatus1.Size = new System.Drawing.Size(349, 45);
            this.rtxStatus1.TabIndex = 7;
            this.rtxStatus1.Text = "";
            // 
            // cbBaudrate1
            // 
            this.cbBaudrate1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbBaudrate1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudrate1.FormattingEnabled = true;
            this.cbBaudrate1.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200",
            "250000",
            "500000",
            "1000000"});
            this.cbBaudrate1.Location = new System.Drawing.Point(263, 100);
            this.cbBaudrate1.Name = "cbBaudrate1";
            this.cbBaudrate1.Size = new System.Drawing.Size(93, 21);
            this.cbBaudrate1.TabIndex = 10;
            this.ttToolTip.SetToolTip(this.cbBaudrate1, "Baudrate used for communication");
            this.cbBaudrate1.SelectedIndexChanged += new System.EventHandler(this.cbBaudrate1_SelectedIndexChanged);
            // 
            // cbPortNamePanel1
            // 
            this.cbPortNamePanel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbPortNamePanel1.FormattingEnabled = true;
            this.cbPortNamePanel1.Location = new System.Drawing.Point(263, 73);
            this.cbPortNamePanel1.Name = "cbPortNamePanel1";
            this.cbPortNamePanel1.Size = new System.Drawing.Size(93, 21);
            this.cbPortNamePanel1.TabIndex = 9;
            this.cbPortNamePanel1.Text = "Select COM";
            // 
            // lbCOM
            // 
            this.lbCOM.AutoSize = true;
            this.lbCOM.Location = new System.Drawing.Point(226, 76);
            this.lbCOM.Name = "lbCOM";
            this.lbCOM.Size = new System.Drawing.Size(31, 13);
            this.lbCOM.TabIndex = 7;
            this.lbCOM.Text = "COM";
            // 
            // lbBAUD
            // 
            this.lbBAUD.AutoSize = true;
            this.lbBAUD.Location = new System.Drawing.Point(220, 103);
            this.lbBAUD.Name = "lbBAUD";
            this.lbBAUD.Size = new System.Drawing.Size(37, 13);
            this.lbBAUD.TabIndex = 8;
            this.lbBAUD.Text = "BAUD";
            // 
            // grBinData
            // 
            this.grBinData.Controls.Add(this.tbBinData);
            this.grBinData.Controls.Add(this.btBinData);
            this.grBinData.Location = new System.Drawing.Point(7, 15);
            this.grBinData.Name = "grBinData";
            this.grBinData.Size = new System.Drawing.Size(374, 61);
            this.grBinData.TabIndex = 6;
            this.grBinData.TabStop = false;
            this.grBinData.Text = "Select Bin Data";
            // 
            // tbBinData
            // 
            this.tbBinData.Location = new System.Drawing.Point(22, 31);
            this.tbBinData.Name = "tbBinData";
            this.tbBinData.Size = new System.Drawing.Size(291, 20);
            this.tbBinData.TabIndex = 5;
            // 
            // btBinData
            // 
            this.btBinData.Location = new System.Drawing.Point(335, 29);
            this.btBinData.Name = "btBinData";
            this.btBinData.Size = new System.Drawing.Size(33, 23);
            this.btBinData.TabIndex = 4;
            this.btBinData.Text = "...";
            this.btBinData.UseVisualStyleBackColor = true;
            this.btBinData.Click += new System.EventHandler(this.btBinData_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.cbLog);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.cbVerify);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.cbOTP);
            this.groupBox7.Location = new System.Drawing.Point(7, 85);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(374, 67);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Option";
            // 
            // cbLog
            // 
            this.cbLog.AutoSize = true;
            this.cbLog.Location = new System.Drawing.Point(298, 32);
            this.cbLog.Name = "cbLog";
            this.cbLog.Size = new System.Drawing.Size(15, 14);
            this.cbLog.TabIndex = 9;
            this.cbLog.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(267, 32);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(25, 13);
            this.label19.TabIndex = 8;
            this.label19.Text = "Log";
            // 
            // cbVerify
            // 
            this.cbVerify.AutoSize = true;
            this.cbVerify.Location = new System.Drawing.Point(195, 32);
            this.cbVerify.Name = "cbVerify";
            this.cbVerify.Size = new System.Drawing.Size(15, 14);
            this.cbVerify.TabIndex = 7;
            this.cbVerify.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(111, 32);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Verify ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 32);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "OTP";
            // 
            // cbOTP
            // 
            this.cbOTP.AutoSize = true;
            this.cbOTP.Location = new System.Drawing.Point(54, 32);
            this.cbOTP.Name = "cbOTP";
            this.cbOTP.Size = new System.Drawing.Size(15, 14);
            this.cbOTP.TabIndex = 3;
            this.cbOTP.UseVisualStyleBackColor = true;
            //this.cbOTP.CheckedChanged += new System.EventHandler(this.cbOTP_CheckedChanged);
            // 
            // grPanel2
            // 
            this.grPanel2.Controls.Add(this.pictureBox2);
            this.grPanel2.Controls.Add(this.rtxStatus2);
            this.grPanel2.Controls.Add(this.cbBaudrate2);
            this.grPanel2.Controls.Add(this.cbPortNamePanel2);
            this.grPanel2.Controls.Add(this.label3);
            this.grPanel2.Controls.Add(this.label4);
            this.grPanel2.Location = new System.Drawing.Point(766, 15);
            this.grPanel2.Name = "grPanel2";
            this.grPanel2.Size = new System.Drawing.Size(373, 142);
            this.grPanel2.TabIndex = 8;
            this.grPanel2.TabStop = false;
            this.grPanel2.Text = "Panel Download 2";
            // 
            // rtxStatus2
            // 
            this.rtxStatus2.Location = new System.Drawing.Point(7, 19);
            this.rtxStatus2.Name = "rtxStatus2";
            this.rtxStatus2.Size = new System.Drawing.Size(349, 45);
            this.rtxStatus2.TabIndex = 7;
            this.rtxStatus2.Text = "";
            // 
            // cbBaudrate2
            // 
            this.cbBaudrate2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbBaudrate2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudrate2.FormattingEnabled = true;
            this.cbBaudrate2.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200",
            "250000",
            "500000",
            "1000000"});
            this.cbBaudrate2.Location = new System.Drawing.Point(263, 100);
            this.cbBaudrate2.Name = "cbBaudrate2";
            this.cbBaudrate2.Size = new System.Drawing.Size(93, 21);
            this.cbBaudrate2.TabIndex = 10;
            this.cbBaudrate2.SelectedIndexChanged += new System.EventHandler(this.cbBaudrate2_SelectedIndexChanged);
            // 
            // cbPortNamePanel2
            // 
            this.cbPortNamePanel2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbPortNamePanel2.FormattingEnabled = true;
            this.cbPortNamePanel2.Location = new System.Drawing.Point(263, 73);
            this.cbPortNamePanel2.Name = "cbPortNamePanel2";
            this.cbPortNamePanel2.Size = new System.Drawing.Size(93, 21);
            this.cbPortNamePanel2.TabIndex = 9;
            this.cbPortNamePanel2.Text = "Select COM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(226, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "COM";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(220, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "BAUD";
            // 
            // grPanel3
            // 
            this.grPanel3.Controls.Add(this.pictureBox3);
            this.grPanel3.Controls.Add(this.rtxStatus3);
            this.grPanel3.Controls.Add(this.cbBaudrate3);
            this.grPanel3.Controls.Add(this.cbPortNamePanel3);
            this.grPanel3.Controls.Add(this.label6);
            this.grPanel3.Controls.Add(this.label7);
            this.grPanel3.Location = new System.Drawing.Point(387, 163);
            this.grPanel3.Name = "grPanel3";
            this.grPanel3.Size = new System.Drawing.Size(373, 147);
            this.grPanel3.TabIndex = 9;
            this.grPanel3.TabStop = false;
            this.grPanel3.Text = "Panel Download 3";
            // 
            // rtxStatus3
            // 
            this.rtxStatus3.Location = new System.Drawing.Point(7, 19);
            this.rtxStatus3.Name = "rtxStatus3";
            this.rtxStatus3.Size = new System.Drawing.Size(349, 45);
            this.rtxStatus3.TabIndex = 7;
            this.rtxStatus3.Text = "";
            // 
            // cbBaudrate3
            // 
            this.cbBaudrate3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbBaudrate3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudrate3.FormattingEnabled = true;
            this.cbBaudrate3.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200",
            "250000",
            "500000",
            "1000000"});
            this.cbBaudrate3.Location = new System.Drawing.Point(263, 100);
            this.cbBaudrate3.Name = "cbBaudrate3";
            this.cbBaudrate3.Size = new System.Drawing.Size(93, 21);
            this.cbBaudrate3.TabIndex = 10;
            this.cbBaudrate3.SelectedIndexChanged += new System.EventHandler(this.cbBaudrate3_SelectedIndexChanged);
            // 
            // cbPortNamePanel3
            // 
            this.cbPortNamePanel3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbPortNamePanel3.FormattingEnabled = true;
            this.cbPortNamePanel3.Location = new System.Drawing.Point(263, 73);
            this.cbPortNamePanel3.Name = "cbPortNamePanel3";
            this.cbPortNamePanel3.Size = new System.Drawing.Size(93, 21);
            this.cbPortNamePanel3.TabIndex = 9;
            this.cbPortNamePanel3.Text = "Select COM";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(226, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "COM";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(220, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "BAUD";
            // 
            // grPanel4
            // 
            this.grPanel4.Controls.Add(this.pictureBox4);
            this.grPanel4.Controls.Add(this.rtxStatus4);
            this.grPanel4.Controls.Add(this.cbBaudrate4);
            this.grPanel4.Controls.Add(this.cbPortNamePanel4);
            this.grPanel4.Controls.Add(this.label9);
            this.grPanel4.Controls.Add(this.label10);
            this.grPanel4.Location = new System.Drawing.Point(767, 163);
            this.grPanel4.Name = "grPanel4";
            this.grPanel4.Size = new System.Drawing.Size(373, 147);
            this.grPanel4.TabIndex = 10;
            this.grPanel4.TabStop = false;
            this.grPanel4.Text = "Panel Download 4";
            // 
            // rtxStatus4
            // 
            this.rtxStatus4.Location = new System.Drawing.Point(6, 19);
            this.rtxStatus4.Name = "rtxStatus4";
            this.rtxStatus4.Size = new System.Drawing.Size(350, 45);
            this.rtxStatus4.TabIndex = 7;
            this.rtxStatus4.Text = "";
            // 
            // cbBaudrate4
            // 
            this.cbBaudrate4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbBaudrate4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudrate4.FormattingEnabled = true;
            this.cbBaudrate4.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200",
            "250000",
            "500000",
            "1000000"});
            this.cbBaudrate4.Location = new System.Drawing.Point(263, 100);
            this.cbBaudrate4.Name = "cbBaudrate4";
            this.cbBaudrate4.Size = new System.Drawing.Size(93, 21);
            this.cbBaudrate4.TabIndex = 10;
            this.cbBaudrate4.SelectedIndexChanged += new System.EventHandler(this.cbBaudrate4_SelectedIndexChanged);
            // 
            // cbPortNamePanel4
            // 
            this.cbPortNamePanel4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbPortNamePanel4.FormattingEnabled = true;
            this.cbPortNamePanel4.Location = new System.Drawing.Point(263, 73);
            this.cbPortNamePanel4.Name = "cbPortNamePanel4";
            this.cbPortNamePanel4.Size = new System.Drawing.Size(93, 21);
            this.cbPortNamePanel4.TabIndex = 9;
            this.cbPortNamePanel4.Text = "Select COM";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(226, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "COM";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(220, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "BAUD";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pictureBox5);
            this.groupBox5.Controls.Add(this.rtxStatus5);
            this.groupBox5.Controls.Add(this.cbBaudrate5);
            this.groupBox5.Controls.Add(this.cbPortNamePanel5);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Location = new System.Drawing.Point(387, 316);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(373, 146);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Panel Download 5";
            // 
            // rtxStatus5
            // 
            this.rtxStatus5.Location = new System.Drawing.Point(6, 19);
            this.rtxStatus5.Name = "rtxStatus5";
            this.rtxStatus5.Size = new System.Drawing.Size(350, 45);
            this.rtxStatus5.TabIndex = 7;
            this.rtxStatus5.Text = "";
            // 
            // cbBaudrate5
            // 
            this.cbBaudrate5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbBaudrate5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudrate5.FormattingEnabled = true;
            this.cbBaudrate5.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200",
            "250000",
            "500000",
            "1000000"});
            this.cbBaudrate5.Location = new System.Drawing.Point(263, 100);
            this.cbBaudrate5.Name = "cbBaudrate5";
            this.cbBaudrate5.Size = new System.Drawing.Size(93, 21);
            this.cbBaudrate5.TabIndex = 10;
            this.cbBaudrate5.SelectedIndexChanged += new System.EventHandler(this.cbBaudrate5_SelectedIndexChanged);
            // 
            // cbPortNamePanel5
            // 
            this.cbPortNamePanel5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbPortNamePanel5.FormattingEnabled = true;
            this.cbPortNamePanel5.Location = new System.Drawing.Point(263, 73);
            this.cbPortNamePanel5.Name = "cbPortNamePanel5";
            this.cbPortNamePanel5.Size = new System.Drawing.Size(93, 21);
            this.cbPortNamePanel5.TabIndex = 9;
            this.cbPortNamePanel5.Text = "Select COM";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(226, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "COM";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(220, 103);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "BAUD";
            // 
            // grPanel6
            // 
            this.grPanel6.Controls.Add(this.pictureBox6);
            this.grPanel6.Controls.Add(this.rtxStatus6);
            this.grPanel6.Controls.Add(this.cbBaudrate6);
            this.grPanel6.Controls.Add(this.cbPortNamePanel6);
            this.grPanel6.Controls.Add(this.label15);
            this.grPanel6.Controls.Add(this.label16);
            this.grPanel6.Location = new System.Drawing.Point(766, 316);
            this.grPanel6.Name = "grPanel6";
            this.grPanel6.Size = new System.Drawing.Size(373, 146);
            this.grPanel6.TabIndex = 12;
            this.grPanel6.TabStop = false;
            this.grPanel6.Text = "Panel Download 6";
            // 
            // rtxStatus6
            // 
            this.rtxStatus6.Location = new System.Drawing.Point(6, 19);
            this.rtxStatus6.Name = "rtxStatus6";
            this.rtxStatus6.Size = new System.Drawing.Size(350, 45);
            this.rtxStatus6.TabIndex = 7;
            this.rtxStatus6.Text = "";
            // 
            // cbBaudrate6
            // 
            this.cbBaudrate6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbBaudrate6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudrate6.FormattingEnabled = true;
            this.cbBaudrate6.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200",
            "250000",
            "500000",
            "1000000"});
            this.cbBaudrate6.Location = new System.Drawing.Point(263, 100);
            this.cbBaudrate6.Name = "cbBaudrate6";
            this.cbBaudrate6.Size = new System.Drawing.Size(93, 21);
            this.cbBaudrate6.TabIndex = 10;
            this.cbBaudrate6.SelectedIndexChanged += new System.EventHandler(this.cbBaudrate6_SelectedIndexChanged);
            // 
            // cbPortNamePanel6
            // 
            this.cbPortNamePanel6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbPortNamePanel6.FormattingEnabled = true;
            this.cbPortNamePanel6.Location = new System.Drawing.Point(263, 73);
            this.cbPortNamePanel6.Name = "cbPortNamePanel6";
            this.cbPortNamePanel6.Size = new System.Drawing.Size(93, 21);
            this.cbPortNamePanel6.TabIndex = 9;
            this.cbPortNamePanel6.Text = "Select COM";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(226, 76);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(31, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "COM";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(220, 103);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "BAUD";
            // 
            // btStartAll
            // 
            this.btStartAll.Location = new System.Drawing.Point(36, 153);
            this.btStartAll.Name = "btStartAll";
            this.btStartAll.Size = new System.Drawing.Size(111, 57);
            this.btStartAll.TabIndex = 13;
            this.btStartAll.Text = "START ALL";
            this.btStartAll.UseVisualStyleBackColor = true;
            this.btStartAll.Click += new System.EventHandler(this.btStartAll_Click);
            // 
            // btEraseAll
            // 
            this.btEraseAll.Location = new System.Drawing.Point(195, 153);
            this.btEraseAll.Name = "btEraseAll";
            this.btEraseAll.Size = new System.Drawing.Size(111, 57);
            this.btEraseAll.TabIndex = 15;
            this.btEraseAll.Text = "ERASE ALL";
            this.btEraseAll.UseVisualStyleBackColor = true;
            this.btEraseAll.Click += new System.EventHandler(this.btEraseAll_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 472);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1150, 22);
            this.statusStrip1.TabIndex = 16;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslStatus
            // 
            this.tsslStatus.Name = "tsslStatus";
            this.tsslStatus.Size = new System.Drawing.Size(16, 17);
            this.tsslStatus.Text = "   ";
            // 
            // rtxStatusAll
            // 
            this.rtxStatusAll.Location = new System.Drawing.Point(90, 53);
            this.rtxStatusAll.Name = "rtxStatusAll";
            this.rtxStatusAll.Size = new System.Drawing.Size(278, 45);
            this.rtxStatusAll.TabIndex = 18;
            this.rtxStatusAll.Text = "";
            // 
            // tbStatusAll
            // 
            this.tbStatusAll.BackColor = System.Drawing.Color.Lime;
            this.tbStatusAll.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbStatusAll.ForeColor = System.Drawing.SystemColors.Window;
            this.tbStatusAll.Location = new System.Drawing.Point(20, 53);
            this.tbStatusAll.MaximumSize = new System.Drawing.Size(100, 100);
            this.tbStatusAll.Multiline = true;
            this.tbStatusAll.Name = "tbStatusAll";
            this.tbStatusAll.Size = new System.Drawing.Size(64, 45);
            this.tbStatusAll.TabIndex = 19;
            this.tbStatusAll.Text = "IDLE";
            this.tbStatusAll.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbStatusAll);
            this.groupBox1.Controls.Add(this.btStartAll);
            this.groupBox1.Controls.Add(this.rtxStatusAll);
            this.groupBox1.Controls.Add(this.btEraseAll);
            this.groupBox1.Location = new System.Drawing.Point(7, 163);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(374, 299);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Panel All Status";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DQS_Flash_JN5xx.Properties.Resources._switch;
            this.pictureBox1.Location = new System.Drawing.Point(36, 70);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::DQS_Flash_JN5xx.Properties.Resources._switch;
            this.pictureBox2.Location = new System.Drawing.Point(43, 70);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(64, 64);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::DQS_Flash_JN5xx.Properties.Resources._switch;
            this.pictureBox3.Location = new System.Drawing.Point(36, 70);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(64, 64);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::DQS_Flash_JN5xx.Properties.Resources._switch;
            this.pictureBox4.Location = new System.Drawing.Point(42, 70);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(64, 64);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::DQS_Flash_JN5xx.Properties.Resources._switch;
            this.pictureBox5.Location = new System.Drawing.Point(36, 69);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(64, 64);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::DQS_Flash_JN5xx.Properties.Resources._switch;
            this.pictureBox6.Location = new System.Drawing.Point(43, 69);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(64, 64);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            // 
            // Form_Flash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 494);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grPanel6);
            this.Controls.Add(this.grPanel4);
            this.Controls.Add(this.grPanel3);
            this.Controls.Add(this.grPanel2);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.grBinData);
            this.Controls.Add(this.grPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Flash";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "JN51xx Flash Programer";
            this.grPanel1.ResumeLayout(false);
            this.grPanel1.PerformLayout();
            this.grBinData.ResumeLayout(false);
            this.grBinData.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.grPanel2.ResumeLayout(false);
            this.grPanel2.PerformLayout();
            this.grPanel3.ResumeLayout(false);
            this.grPanel3.PerformLayout();
            this.grPanel4.ResumeLayout(false);
            this.grPanel4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.grPanel6.ResumeLayout(false);
            this.grPanel6.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grPanel1;
        private System.Windows.Forms.RichTextBox rtxStatus1;
        private System.Windows.Forms.ComboBox cbBaudrate1;
        private System.Windows.Forms.ComboBox cbPortNamePanel1;
        private System.Windows.Forms.Label lbCOM;
        private System.Windows.Forms.Label lbBAUD;
        private System.Windows.Forms.GroupBox grBinData;
        private System.Windows.Forms.Button btBinData;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox cbLog;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox cbVerify;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox cbOTP;
        private System.Windows.Forms.GroupBox grPanel2;
        private System.Windows.Forms.RichTextBox rtxStatus2;
        private System.Windows.Forms.ComboBox cbBaudrate2;
        private System.Windows.Forms.ComboBox cbPortNamePanel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grPanel3;
        private System.Windows.Forms.RichTextBox rtxStatus3;
        private System.Windows.Forms.ComboBox cbBaudrate3;
        private System.Windows.Forms.ComboBox cbPortNamePanel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox grPanel4;
        private System.Windows.Forms.RichTextBox rtxStatus4;
        private System.Windows.Forms.ComboBox cbBaudrate4;
        private System.Windows.Forms.ComboBox cbPortNamePanel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RichTextBox rtxStatus5;
        private System.Windows.Forms.ComboBox cbBaudrate5;
        private System.Windows.Forms.ComboBox cbPortNamePanel5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox grPanel6;
        private System.Windows.Forms.RichTextBox rtxStatus6;
        private System.Windows.Forms.ComboBox cbBaudrate6;
        private System.Windows.Forms.ComboBox cbPortNamePanel6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btStartAll;
        private System.Windows.Forms.Button btEraseAll;
        private System.Windows.Forms.ToolTip ttToolTip;
        private System.Windows.Forms.OpenFileDialog ofdOpen;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslStatus;
        private System.Windows.Forms.RichTextBox rtxStatusAll;
        private System.Windows.Forms.TextBox tbStatusAll;
        private System.Windows.Forms.TextBox tbBinData;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}

